/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author shayn
 */
public class TestApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //corrected error on line 17 with use of the error icon missing ; argument
        System.out.println("Sucess!");
        //use code compleation feature for test 2
        System.out.println("Test 2");
        //used list feature to complete "end of Test"
        System.out.println("end of Test");
        //used Sout feature in netbeans to complete line 23
        System.out.println("Sout Sucess");
    }
}
