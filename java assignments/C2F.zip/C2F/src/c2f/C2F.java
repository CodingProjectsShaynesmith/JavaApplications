/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package c2f;

import java.util.Scanner;

public class C2F {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String tempratureconv;

        System.out.println("Welcome to the Temperature Converter");

        do {
            System.out.print("\nEnter degrees in Celsius => ");
            double celsius = sc.nextDouble();
            double fahrenheit = (celsius * 9 / 5) + 32;

            // Format output for Fahrenheit
            System.out.printf("Degrees in Fahrenheit: %.1f%n", fahrenheit);
            
            System.out.print("\nContinue? (y / n) : ");
            tempratureconv = sc.next();
        } while (tempratureconv.equalsIgnoreCase("y"));

        sc.close();
    }
}
