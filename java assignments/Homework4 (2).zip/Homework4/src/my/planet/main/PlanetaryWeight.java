package my.planet.main;

import java.util.Scanner;
import my.planet.enums.Planets;

public class PlanetaryWeight {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            boolean continueCalculating = true;
            
            while (continueCalculating) {
                System.out.println("Weight Calculator");
                System.out.print("\nEnter your weight on Earth => ");
                int earthWeight = sc.nextInt();
                System.out.print("\n");
                System.out.printf("\n%-10s\t%-10s%n", "\tPlanet", "Weight");
                System.out.printf("%-10s\t%-10s", "\t=====", "=====");
                System.out.print("\n");

                
                // Calculate weight on each planet
                for (Planets planet : Planets.values()) {
                    double planetaryWeight = earthWeight * planet.getGravityFactor();
                    System.out.printf("%10s\t%10.2f%n", planet.getPlanetName(), planetaryWeight);
                }
                
                // Check if the user wants to continue
                System.out.print("Do you want to go again? (y/n): ");
                String response = sc.next();
                continueCalculating = response.equalsIgnoreCase("y");
            }
        }
    }
}
