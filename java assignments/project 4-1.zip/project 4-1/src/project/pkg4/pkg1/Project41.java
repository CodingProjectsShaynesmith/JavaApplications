/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project.pkg4.pkg1;

import java.util.Scanner;

public class Project41 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char continueChoice;

        System.out.println("Welcome To the Squares and Cubes Table");

        do {
            System.out.print("\nEnter an integer: ");
            int n = scanner.nextInt();

            // Print the header
            System.out.printf("\n%-8s\t%-8s\t%-8s%n", "Number", "Squared", "Cubed");
            System.out.printf("%-8s\t%-8s\t%-8s%n", "=======", "=======", "=======");

            // Formula for Squares and cubes
            for (int x = 1; x <= n; x++) {
                System.out.printf("%-8d\t%8d\t%8d%n", x, x * x, x * x * x);
            }

            // Ask if the user wants to continue
            System.out.print("Continue? (y/n) : ");
            continueChoice = scanner.next().charAt(0);

        } while (Character.toLowerCase(continueChoice) == 'y');

        System.out.println("Press any key to continue . . .");
        scanner.nextLine(); // Consume the newline
        scanner.nextLine(); // Wait for user input to exit
    }
}

