/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab3;

import java.util.Scanner;
import my.enums.Change;

/**
 *
 * @author shayn
 */
public class MakeChange {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int val;
        int coins;
        String again;
        Scanner sc = new Scanner(System.in);
        System.out.println("");
        System.out.print("Welcme to the change Calculator");
        do {
            System.out.print("\nEnter number of cents (0-99) => ");
            val = sc.nextInt();
            System.out.println("");
            for (Change c : Change.values()) {
                coins = val / c.getCoinValue();
              //  val = val % c.getCoinValue();
                val %= c.getCoinValue();
                System.out.print("There " + (coins != 1 ? "are " : "is ")
                        + coins
                        + " " + c.getCoinName());
                if (coins != 1) {
                    if (c == Change.PENNY) {
                        System.out.println("\bies here");
                    } else {
                        System.out.println("s here");
                    }
                } else {
                    System.out.println(" here");}
            
                }//end object for loop
                System.out.print("\nWanna go again? ");
                again = sc.next();
            } while (again.substring(0, 1).equalsIgnoreCase("y"));
        } 
    }
