/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package my.enums;

/**
 *
 * @author shayn
 */
public enum Change {
    QUARTER ("Quarter",25),
    DIME ("Dime",10),
    NICKLE ("Nickle",5),
    PENNY("Penny",1);
    private String coinName;
    private int coinValue;
    
    private Change(String coinName, int coinValue) {
        this.coinName = coinName;
        this.coinValue = coinValue;
    }

    @Override
    public String toString() {
        return getCoinName();
    }

    /**
     * @return the coinName
     */
    public String getCoinName() {
        return coinName;
    }

    /**
     * @return the coinValue
     */
    public int getCoinValue() {
        return coinValue;
    }

}
